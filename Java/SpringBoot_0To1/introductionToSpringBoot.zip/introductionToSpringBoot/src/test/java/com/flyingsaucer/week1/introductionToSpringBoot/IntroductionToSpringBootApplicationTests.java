package com.flyingsaucer.week1.introductionToSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntroductionToSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
